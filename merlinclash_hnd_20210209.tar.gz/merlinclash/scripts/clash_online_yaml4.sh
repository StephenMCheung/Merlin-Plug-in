#!/bin/sh

export KSROOT=/koolshare
source $KSROOT/scripts/base.sh
eval $(dbus export merlinclash_)
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'
LOG_FILE=/tmp/upload/merlinclash_log.txt

rm -rf /tmp/upload/merlinclash_log.txt
rm -rf /tmp/upload/*.yaml
LOCK_FILE=/var/lock/yaml_online_update.lock
flag=0
upname=""
upname_tmp=""
subscription_type="4"
dictionary=/koolshare/merlinclash/yaml_bak/subscription.txt
updateflag=""
mcflag=$merlinclash_flag
Regularlog=/tmp/upload/merlinclash_regular.log
rm -rf $Regularlog
get_acl4ssrsel_name() {
	case "$1" in
		ZHANG)
			echo "Merlin Clash_常规规则"
		;;
		ZHANG_Area_Fallback)
			echo "Merlin Clash_分区域故障转移"
		;;
		ZHANG_Area_Urltest)
			echo "Merlin Clash_分区域自动测速"
		;;
		ZHANG_Area_NoAuto)
			echo "Merlin Clash_分区域无自动测速"
		;;
		ZHANG_Area_Media)
			echo "Merlin Clash_媒体与分区域自动测速"
		;;
		ZHANG_Area_Media_NoAuto)
			echo "Merlin Clash_媒体与分区域无自动测速"
		;;
		ACL4SSR_Online)
			echo "Online默认版_分组比较全"
		;;
		ACL4SSR_Online_AdblockPlus)
			echo "AdblockPlus_更多去广告"
		;;
		ACL4SSR_Online_NoAuto)
			echo "NoAuto_无自动测速"
		;;
		ACL4SSR_Online_NoReject)
			echo "NoReject_无广告拦截规则"
		;;
		ACL4SSR_Online_Mini)
			echo "Mini_精简版"
		;;
		ACL4SSR_Online_Mini_AdblockPlus)
			echo "Mini_AdblockPlus_精简版更多去广告"
		;;
		ACL4SSR_Online_Mini_NoAuto)
			echo "Mini_NoAuto_精简版无自动测速"
		;;
		ACL4SSR_Online_Mini_Fallback)
			echo "Mini_Fallback_精简版带故障转移"
		;;
		ACL4SSR_Online_Mini_MultiMode)
			echo "Mini_MultiMode_精简版自动测速故障转移负载均衡"
		;;
		ACL4SSR_Online_Full)
			echo "Full全分组_重度用户使用"
		;;
		ACL4SSR_Online_Full_NoAuto)
			echo "Full全分组_无自动测速"
		;;
		ACL4SSR_Online_Full_AdblockPlus)
			echo "Full全分组_更多去广告"
		;;
		ACL4SSR_Online_Full_Netflix)
			echo "Full全分组_奈飞全量"
		;;
		ACL4SSR_Online_Full_Google)
			echo "Full全分组_谷歌细分"
		;;
		ACL4SSR_Online_Full_MultiMode)
			echo "Full全分组_多模式"
		;;
		ACL4SSR_Online_Mini_MultiCountry)
			echo "Full全分组_多国家地区"
		;;
	esac
}

start_online_update_hnd(){
	clashtarget=$merlinclash_clashtarget
	acl4ssrsel=$merlinclash_acl4ssrsel
	emoji=$merlinclash_subconverter_emoji
	udp=$merlinclash_subconverter_udp
	appendtype=$merlinclash_subconverter_append_type
	sort=$merlinclash_subconverter_sort
	fnd=$merlinclash_subconverter_fdn
	scv=$merlinclash_subconverter_scv
	tfo=$merlinclash_subconverter_tfo
	include=$merlinclash_subconverter_include
	exclude=$merlinclash_subconverter_exclude
	updateflag="start_online_update"
	customrule=$merlinclash_customrule_cbox
	if [ "$emoji" == "1" ]; then
		emoji="true"
	else
		emoji="false"
	fi
	if [ "$udp" == "1" ]; then
		udp="true"
	else
		udp="false"
	fi
	if [ "$appendtype" == "1" ]; then
		appendtype="true"
	else
		appendtype="false"
	fi
	if [ "$sort" == "1" ]; then
		sort="true"
	else
		sort="false"
	fi
	if [ "$fnd" == "1" ]; then
		fnd="true"
	else
		fnd="false"
	fi
	if [ "$scv" == "1" ]; then
		scv="true"
	else
		scv="false"
	fi
	if [ "$tfo" == "1" ]; then
		tfo="true"
	else
		tfo="false"
	fi
		#20200807处理%0A替换成%7C，换行替换成|
		merlinc_link=$(echo $merlinclash_links3 | sed 's/%0A/%7C/g')
		upname_tmp="$merlinclash_uploadrename4"
		#echo_date "订阅文件重命名为：$upname_tmp" >> $LOG_FILE
		time=$(date "+%Y%m%d-%H%M%S")
		newname=$(echo $time | awk -F'-' '{print $2}')
		echo_date "配置名是：$upname_tmp" >> $LOG_FILE
		if [ "$customrule" == "0" ]; then
			case $acl4ssrsel in
			ZHANG)
				_name="MCC_"
				;;
			ZHANG_Area_Fallback)
				_name="MAF_"
				;;
			ZHANG_Area_Urltest)
				_name="MAU_"
				;;	
			ZHANG_Area_NoAuto)
				_name="MAN_"
				;;	
			ZHANG_Area_Media)
				_name="MAM_"
				;;	
			ZHANG_Area_Media_NoAuto)
				_name="MAMN_"
				;;
			ACL4SSR_Online)
				_name="OL_"
				;;
			ACL4SSR_Online_AdblockPlus)
				_name="AP_"
				;;
			ACL4SSR_Online_NoAuto)
				_name="NA_"
				;;
			ACL4SSR_Online_NoReject)
				_name="NR_"
				;;
			ACL4SSR_Online_Mini)
				_name="Mini_"
				;;
			ACL4SSR_Online_Mini_AdblockPlus)
				_name="MAP_"
				;;
			ACL4SSR_Online_Mini_NoAuto)
				_name="MNA_"
				;;
			ACL4SSR_Online_Mini_Fallback)
				_name="MF_"
				;;
			ACL4SSR_Online_Mini_MultiMode)
				_name="MMM_"
				;;
			ACL4SSR_Online_Full)
				_name="Full_"
				;;
			ACL4SSR_Online_Full_NoAuto)
				_name="FNA_"
				;;
			ACL4SSR_Online_Full_AdblockPlus)
				_name="FAP_"
				;;
			ACL4SSR_Online_Full_Netflix)
				_name="FNX_"
				;;
			ACL4SSR_Online_Full_Google)
				_name="FGG_"
				;;
			ACL4SSR_Online_Full_MultiMode)
				_name="FMM_"
				;;
			ACL4SSR_Online_Mini_MultiCountry)
				_name="MMC_"
				;;
			esac
			links="http://localhost:25500/sub?target=$clashtarget&new_name=true&url=$merlinc_link&insert=false&config=ruleconfig%2F${acl4ssrsel}.ini&include=$include&exclude=$exclude&append_type=$appendtype&emoji=$emoji&udp=$udp&fdn=$fdn&sort=$sort&scv=$scv&tfo=$tfo"
		else
			acl4ssrsel=$merlinclash_acl4ssrsel_cus
			_name="CUS_"
			links="http://localhost:25500/sub?target=$clashtarget&new_name=true&url=$merlinc_link&insert=false&config=customconfig%2F${acl4ssrsel}.ini&include=$include&exclude=$exclude&append_type=$appendtype&emoji=$emoji&udp=$udp&fdn=$fdn&sort=$sort&scv=$scv&tfo=$tfo"
		fi
		if [ "$customrule" == "0" ]; then
			echo_date "订阅规则类型是：$(get_acl4ssrsel_name $acl4ssrsel)" >> $LOG_FILE
		else
			echo_date "订阅规则是：$acl4ssrsel" >> $LOG_FILE
		fi
		echo_date "subconverter进程：$(pidof subconverter)" >> $LOG_FILE
		echo_date "即将开始转换，需要一定时间，请等候处理" >> $LOG_FILE
		sleep 3s
		echo_date "生成订阅链接：$links" >> $LOG_FILE
		if [ -n "$upname_tmp" ]; then
			upname="$_name$upname_tmp.yaml"
		else
			upname="$_name$newname.yaml"
		fi
			#wget下载文件
			#wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$links"
			UA='Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1667.0 Safari/537.36'
			echo_date "使用常规网络下载..." >> $LOG_FILE
			curl -4sSk --user-agent "$UA" --connect-timeout 30 "$links" > /tmp/upload/$upname
			echo_date "配置文件下载完成" >>$LOG_FILE
			#虽然为0但是还是要检测下是否下载到正确的内容
			if [ "$?" == "0" ];then
				#下载为空...
				if [ -z "$(cat /tmp/upload/$upname)" ]; then
					echo_date "使用curl下载成功，但是内容为空，尝试更换wget进行下载..."	>> $LOG_FILE
					rm /tmp/upload/$upname
					wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$links"
				fi	
				echo_date "检查文件完整性" >> $LOG_FILE
				if [ -z "$(cat /tmp/upload/$upname)" ];then 
					echo_date "获取clash配置文件失败！" >> $LOG_FILE
					failed_warning_clash
				else
					echo_date "检查下载是否正确" >> $LOG_FILE
					local blank=$(cat /tmp/upload/$upname | grep -E " |Redirecting|301")
					local blank2=$(cat /tmp/upload/$upname | grep -E " |The following link doesn't contain any valid node info")
					local blakflg="0"				
					if [ "$blakflg" == "0" ] && [ -n "$blank" ]; then
						echo_date "订阅链接可能有跳转，尝试更换wget进行下载..." >> $LOG_FILE
						rm /tmp/upload/$upname
						if [ -n $(echo $links | grep -E "^https") ]; then
							wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$links"						
						else
							wget -t3 -T30 -4 -O /tmp/upload/$upname "$links"	
						fi
						blakflg="1"
					fi
					if [ "$blakflg" == "0" ] && [ -n "$blank2" ]; then
						echo_date "curl下载出错，尝试更换wget进行下载..." >> $LOG_FILE
						rm /tmp/upload/$upname
						if [ -n $(echo $links | grep -E "^https") ]; then
							wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$links"						
						else
							wget -t3 -T30 -4 -O /tmp/upload/$upname "$links"	
						fi
						blakflg="1"
					fi
					#下载为空...
					if [ -z "$(cat /tmp/upload/$upname)" ]; then
						echo_date "下载内容为空..."
						failed_warning_clash
					fi
					echo_date "已获取clash配置文件" >> $LOG_FILE
					echo_date "yaml文件合法性检查" >> $LOG_FILE	
					check_yamlfile
					if [ $flag == "1" ]; then
					#执行上传文件名.yaml处理工作，包括去注释，去空白行，去除dns以上头部，将标准头部文件复制一份到/tmp/ 跟tmp的标准头部文件合并，生成新的head.yaml，再将head.yaml复制到/koolshare/merlinclash/并命名为upload.yaml
						echo_date "执行yaml文件处理工作" >> $LOG_FILE
						sh /koolshare/scripts/clash_yaml_sub.sh #>/dev/null 2>&1 &
						#20200803写入字典
						write_dictionary
						echo_date "订阅完成" >> $LOG_FILE
					else
						echo_date "yaml文件格式不合法" >> $LOG_FILE
					fi
				fi
			else
				echo_date "下载超时" >> $LOG_FILE
				failed_warning_clash
			fi
}

start_dc_online_update_hnd(){
	clashtarget=$merlinclash_dc_clashtarget
	acl4ssrsel=$merlinclash_dc_acl4ssrsel	
	emoji=$merlinclash_dc_subconverter_emoji
	udp=$merlinclash_dc_subconverter_udp
	appendtype=$merlinclash_dc_subconverter_append_type
	sort=$merlinclash_dc_subconverter_sort
	fnd=$merlinclash_dc_subconverter_fdn
	scv=$merlinclash_dc_subconverter_scv
	tfo=$merlinclash_dc_subconverter_tfo
	include=$merlinclash_dc_subconverter_include
	exclude=$merlinclash_dc_subconverter_exclude
	customrule="0"
	updateflag="start_online_update"
	if [ "$emoji" == "1" ]; then
		emoji="true"
	else
		emoji="false"
	fi
	if [ "$udp" == "1" ]; then
		udp="true"
	else
		udp="false"
	fi
	if [ "$appendtype" == "1" ]; then
		appendtype="true"
	else
		appendtype="false"
	fi
	if [ "$sort" == "1" ]; then
		sort="true"
	else
		sort="false"
	fi
	if [ "$fnd" == "1" ]; then
		fnd="true"
	else
		fnd="false"
	fi
	if [ "$scv" == "1" ]; then
		scv="true"
	else
		scv="false"
	fi
	if [ "$tfo" == "1" ]; then
		tfo="true"
	else
		tfo="false"
	fi
	#20200807处理%0A替换成%7C，换行替换成|
	merlinc_link=$(echo $merlinclash_dc_links3 | sed 's/%0A/%7C/g')
		upname_tmp="$merlinclash_dc_uploadrename4"
		#echo_date "订阅文件重命名为：$upname_tmp" >> $LOG_FILE
		time=$(date "+%Y%m%d-%H%M%S")
		newname=$(echo $time | awk -F'-' '{print $2}')
		echo_date "订阅规则类型是：$(get_acl4ssrsel_name $acl4ssrsel)"
		echo_date "subconverter进程：$(pidof subconverter)" >> $LOG_FILE
		echo_date "即将开始转换，需要一定时间，请等候处理" >> $LOG_FILE
		sleep 3s
		case $acl4ssrsel in
		ZHANG)
			_name="MCC_"
			;;
		ZHANG_Area_Fallback)
			_name="MAF_"
			;;
		ZHANG_Area_Urltest)
			_name="MAU_"
			;;	
		ZHANG_Area_NoAuto)
			_name="MAUN_"
			;;	
		ZHANG_Area_Media)
			_name="MAM_"
			;;
		ZHANG_Area_Media_NoAuto)
			_name="MAMN_"
			;;
		ACL4SSR_Online)
			_name="OL_"
			;;
		ACL4SSR_Online_AdblockPlus)
			_name="AP_"
			;;
		ACL4SSR_Online_NoAuto)
			_name="NA_"
			;;
		ACL4SSR_Online_NoReject)
			_name="NR_"
			;;
		ACL4SSR_Online_Mini)
			_name="Mini_"
			;;
		ACL4SSR_Online_Mini_AdblockPlus)
			_name="MAP_"
			;;
		ACL4SSR_Online_Mini_NoAuto)
			_name="MNA_"
			;;
		ACL4SSR_Online_Mini_Fallback)
			_name="MF_"
			;;
		ACL4SSR_Online_Mini_MultiMode)
			_name="MMM_"
			;;
		ACL4SSR_Online_Full)
			_name="Full_"
			;;
		ACL4SSR_Online_Full_NoAuto)
			_name="FNA_"
			;;
		ACL4SSR_Online_Full_AdblockPlus)
			_name="FAP_"
			;;
		ACL4SSR_Online_Full_Netflix)
			_name="FNX_"
			;;
		ACL4SSR_Online_Full_Google)
			_name="FGG_"
			;;
		ACL4SSR_Online_Full_MultiMode)
			_name="FMM_"
			;;
		ACL4SSR_Online_Mini_MultiCountry)
			_name="MMC_"
			;;
		esac
		links="http://localhost:25500/sub?target=$clashtarget&new_name=true&url=$merlinc_link&insert=false&config=ruleconfig%2F${acl4ssrsel}.ini&include=$include&exclude=$exclude&append_type=$appendtype&emoji=$emoji&udp=$udp&fdn=$fdn&sort=$sort&scv=$scv&tfo=$tfo"
		
		echo_date "生成订阅链接：$links" >> $LOG_FILE
		if [ -n "$upname_tmp" ]; then
			upname="$_name$upname_tmp.yaml"
		else
			upname="$_name$newname.yaml"
		fi
			#wget下载文件
			#wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$links"
			UA='Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1667.0 Safari/537.36'
			echo_date "使用常规网络下载..." >> $LOG_FILE
			curl --user-agent "$UA" --connect-timeout 30 -s "$links" > /tmp/upload/$upname
			echo_date "配置文件下载完成" >>$LOG_FILE
			if [ "$?" == "0" ];then
				#下载为空...
				if [ -z "$(cat /tmp/upload/$upname)" ]; then
					echo_date "使用curl下载成功，但是内容为空，尝试更换wget进行下载..."	>> $LOG_FILE
					rm /tmp/upload/$upname
					wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$links"
				fi
				echo_date "检查文件完整性" >> $LOG_FILE
				if [ -z "$(cat /tmp/upload/$upname)" ];then 
					echo_date "获取clash配置文件失败！" >> $LOG_FILE
					failed_warning_clash
				else
					echo_date "检查下载是否正确" >> $LOG_FILE
					local blank=$(cat /tmp/upload/$upname | grep -E " |Redirecting|301")
					local blank2=$(cat /tmp/upload/$upname | grep -E " |The following link doesn't contain any valid node info")
					local blakflg="0"				
					if [ "$blakflg" == "0" ] && [ -n "$blank" ]; then
						echo_date "订阅链接可能有跳转，尝试更换wget进行下载..." >> $LOG_FILE
						rm /tmp/upload/$upname
						if [ -n $(echo $links | grep -E "^https") ]; then
							wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$links"						
						else
							wget -t3 -T30 -4 -O /tmp/upload/$upname "$links"	
						fi
						blakflg="1"
					fi
					if [ "$blakflg" == "0" ] && [ -n "$blank2" ]; then
						echo_date "curl下载出错，尝试更换wget进行下载..." >> $LOG_FILE
						rm /tmp/upload/$upname
						if [ -n $(echo $links | grep -E "^https") ]; then
							wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$links"						
						else
							wget -t3 -T30 -4 -O /tmp/upload/$upname "$links"	
						fi
						blakflg="1"
					fi
					#下载为空...
					if [ -z "$(cat /tmp/upload/$upname)" ]; then
						echo_date "下载内容为空..." >> $LOG_FILE
						failed_warning_clash
					fi
					echo_date "已获取clash配置文件" >> $LOG_FILE
					echo_date "yaml文件合法性检查" >> $LOG_FILE	
					check_yamlfile
					if [ $flag == "1" ]; then
					#执行上传文件名.yaml处理工作，包括去注释，去空白行，去除dns以上头部，将标准头部文件复制一份到/tmp/ 跟tmp的标准头部文件合并，生成新的head.yaml，再将head.yaml复制到/koolshare/merlinclash/并命名为upload.yaml
						echo_date "执行yaml文件处理工作" >> $LOG_FILE
						sh /koolshare/scripts/clash_yaml_sub.sh #>/dev/null 2>&1 &
						#20200803写入字典
						write_dictionary
						echo_date "订阅完成" >> $LOG_FILE
					else
						echo_date "yaml文件格式不合法" >> $LOG_FILE
						failed_warning_clash
					fi
				fi
			else
				echo_date "下载超时" >> $LOG_FILE
				failed_warning_clash
			fi
	#fi
}

start_regular_update_hnd(){
	#$name $type $link $clashtarget $acltype $emoji $udp $appendtype $sort $fnd $include $exclude $scv $tfo
	#$1    $2    $3    $4           $5       $6      $7    $8         $9   ${10} ${11}    ${12}   ${13} ${14}
	emoji=$6
	echo_date "emoji:$emoji" >> $Regularlog

	udp=$7
	echo_date "udp:$udp" >> $Regularlog

	appendtype=$8
	echo_date "节点显示类型:$appendtype" >> $Regularlog

	sort=$9
	echo_date "节点排序:$sort" >> $Regularlog

	fnd=${10}
	echo_date "过滤非法节点:$fnd" >> $Regularlog
	
	scv=${13}
	echo_date "跳过证书验证:$scv" >> $Regularlog

	tfo=${14}
	echo_date "TCP FAST OPEN:$tfo" >> $Regularlog

	include=${11}
	echo_date "包含节点:$include" >> $Regularlog

	exclude=${12}
	echo_date "排除节点:$exclude" >> $Regularlog

	customrule=${15}
	echo_date "自定订阅标记:$customrule" >> $Regularlog

	updateflag="start_regular_update"
	
	merlinc_link=$3	
	upname_tmp=$1
	acltype_tmp=$5
	merlinclash_clashtarget=$4
	dbus set merlinclash_clashtarget=$merlinclash_clashtarget
	echo_date "clashtarget: $merlinclash_clashtarget" >> $Regularlog
	echo_date "订阅地址是：$merlinc_link" >> $Regularlog
	echo_date "【配置名是：$upname_tmp】" >> $Regularlog
	if [ "$customrule" == "0" ]; then
		case $acltype_tmp in
		ZHANG)
			_name="MCC_"
			;;
		ZHANG_Area_Fallback)
			_name="MAF_"
			;;
		ZHANG_Area_Urltest)
			_name="MAU_"
			;;
		ZHANG_Area_NoAuto)
			_name="MAUN_"
			;;	
		ZHANG_Area_Media)
			_name="MAM_"
			;;
		ZHANG_Area_Media_NoAuto)
			_name="MAMN_"
			;;
		ACL4SSR_Online)
			_name="OL_"
			;;
		ACL4SSR_Online_AdblockPlus)
			_name="AP_"
			;;
		ACL4SSR_Online_NoAuto)
			_name="NA_"
			;;
		ACL4SSR_Online_NoReject)
			_name="NR_"
			;;
		ACL4SSR_Online_Mini)
			_name="Mini_"
			;;
		ACL4SSR_Online_Mini_AdblockPlus)
			_name="MAP_"
			;;
		ACL4SSR_Online_Mini_NoAuto)
			_name="MNA_"
			;;
		ACL4SSR_Online_Mini_Fallback)
			_name="MF_"
			;;
		ACL4SSR_Online_Mini_MultiMode)
			_name="MMM_"
			;;
		ACL4SSR_Online_Full)
			_name="Full_"
			;;
		ACL4SSR_Online_Full_NoAuto)
			_name="FNA_"
			;;
		ACL4SSR_Online_Full_AdblockPlus)
			_name="FAP_"
			;;
		ACL4SSR_Online_Full_Netflix)
			_name="FNX_"
			;;
		ACL4SSR_Online_Full_Google)
			_name="FGG_"
			;;
		ACL4SSR_Online_Full_MultiMode)
			_name="FMM_"
			;;
		ACL4SSR_Online_Mini_MultiCountry)
			_name="MMC_"
			;;
		esac
		links="http://localhost:25500/sub?target=$merlinclash_clashtarget&new_name=true&url=$merlinc_link&insert=false&config=ruleconfig%2F${acltype_tmp}.ini&include=$include&exclude=$exclude&append_type=$appendtype&emoji=$emoji&udp=$udp&fdn=$fdn&sort=$sort&scv=$scv&tfo=$tfo"
	else
		_name="CUS_"
		links="http://localhost:25500/sub?target=$merlinclash_clashtarget&new_name=true&url=$merlinc_link&insert=false&config=customconfig%2F${acltype_tmp}.ini&include=$include&exclude=$exclude&append_type=$appendtype&emoji=$emoji&udp=$udp&fdn=$fdn&sort=$sort&scv=$scv&tfo=$tfo"
	fi
	if [ "$customrule" == "0" ]; then
		echo_date "订阅规则类型是：$(get_acl4ssrsel_name $acltype_tmp)" >> $Regularlog
	else
		echo_date "订阅规则是：$acltype_tmp" >> $Regularlog
	fi
	echo_date "subconverter进程：$(pidof subconverter)" >> $Regularlog
	echo_date "即将开始转换，需要一定时间，请等候处理" >> $Regularlog
	sleep 3s	
	echo_date "生成订阅链接：$links" >> $Regularlog
	upname="${_name}${upname_tmp}.yaml"
		
	#wget下载文件
	#wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$links"
	UA='Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1667.0 Safari/537.36'
	echo_date "使用常规网络下载..." >> $Regularlog
	curl --user-agent "$UA" --connect-timeout 30 -s "$links" > /tmp/upload/$upname
	echo_date "配置文件下载完成" >>$Regularlog
	if [ "$?" == "0" ];then
		#下载为空...
		if [ -z "$(cat /tmp/upload/$upname)" ]; then
			echo_date "使用curl下载成功，但是内容为空，尝试更换wget进行下载..."	>> $Regularlog
			rm /tmp/upload/$upname
			wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$links"
		fi
		echo_date "检查文件完整性" >> $Regularlog
		if [ -z "$(cat /tmp/upload/$upname)" ];then 
			echo_date "获取clash配置文件失败！" >> $Regularlog
			failed_warning_clash
		else
			echo_date "检查下载是否正确" >> $Regularlog
			local blank=$(cat /tmp/upload/$upname | grep -E " |Redirecting|301")
			local blank2=$(cat /tmp/upload/$upname | grep -E " |The following link doesn't contain any valid node info")
			local blakflg="0"				
			if [ "$blakflg" == "0" ] && [ -n "$blank" ]; then
				echo_date "订阅链接可能有跳转，尝试更换wget进行下载..." >> $Regularlog
				rm /tmp/upload/$upname
				if [ -n $(echo $links | grep -E "^https") ]; then
					wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$links"						
				else
					wget -t3 -T30 -4 -O /tmp/upload/$upname "$links"	
				fi
				blakflg="1"
			fi
			if [ "$blakflg" == "0" ] && [ -n "$blank2" ]; then
				echo_date "curl下载出错，尝试更换wget进行下载..." >> $Regularlog
				rm /tmp/upload/$upname
				if [ -n $(echo $links | grep -E "^https") ]; then
					wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$links"						
				else
					wget -t3 -T30 -4 -O /tmp/upload/$upname "$links"	
				fi
				blakflg="1"
			fi
			#下载为空...
			if [ -z "$(cat /tmp/upload/$upname)" ]; then
				echo_date "下载内容为空..." >> $Regularlog
				failed_warning_clash
			fi
			echo_date "已获取clash配置文件" >> $Regularlog
			echo_date "yaml文件合法性检查" >> $Regularlog
			check_yamlfile
			if [ $flag == "1" ]; then
			#执行上传文件名.yaml处理工作，包括去注释，去空白行，去除dns以上头部，将标准头部文件复制一份到/tmp/ 跟tmp的标准头部文件合并，生成新的head.yaml，再将head.yaml复制到/koolshare/merlinclash/并命名为upload.yaml
				echo_date "执行yaml文件处理工作" >> $Regularlog
				sh /koolshare/scripts/clash_yaml_sub.sh #>/dev/null 2>&1 &
				#20200803写入字典
				write_dictionary
				echo_date "订阅完成" >> $Regularlog
			else
				echo_date "yaml文件格式不合法" >> $Regularlog
			fi
		fi
	else
		echo_date "下载超时" >> $Regularlog
		failed_warning_clash
	fi
}
start_online_update_384(){
	clashtarget=$merlinclash_clashtarget
	acl4ssrsel=$merlinclash_acl4ssrsel
	emoji=$merlinclash_subconverter_emoji
	udp=$merlinclash_subconverter_udp
	appendtype=$merlinclash_subconverter_append_type
	sort=$merlinclash_subconverter_sort
	fnd=$merlinclash_subconverter_fdn
	scv=$merlinclash_subconverter_scv
	tfo=$merlinclash_subconverter_tfo
	include=$merlinclash_subconverter_include
	exclude=$merlinclash_subconverter_exclude
	addr=$merlinclash_subconverter_addr
	updateflag="start_online_update"
	if [ "$emoji" == "1" ]; then
		emoji="true"
	else
		emoji="false"
	fi
	if [ "$udp" == "1" ]; then
		udp="true"
	else
		udp="false"
	fi
	if [ "$appendtype" == "1" ]; then
		appendtype="true"
	else
		appendtype="false"
	fi
	if [ "$sort" == "1" ]; then
		sort="true"
	else
		sort="false"
	fi
	if [ "$fnd" == "1" ]; then
		fnd="true"
	else
		fnd="false"
	fi
	if [ "$scv" == "1" ]; then
		scv="true"
	else
		scv="false"
	fi
	if [ "$tfo" == "1" ]; then
		tfo="true"
	else
		tfo="false"
	fi
	#20200807处理%0A替换成%7C，换行替换成|
	merlinc_link=$(echo $merlinclash_links3 | sed 's/%0A/%7C/g')
		upname_tmp="$merlinclash_uploadrename4"
		time=$(date "+%Y%m%d-%H%M%S")
		newname=$(echo $time | awk -F'-' '{print $2}')
		echo_date "配置名是：$upname_tmp" >> $LOG_FILE
		echo_date "订阅规则类型是：$(get_acl4ssrsel_name $acl4ssrsel)" >> $LOG_FILE
		echo_date "订阅后端地址是：$addr" >> $LOG_FILE
		echo_date "即将开始转换，需要一定时间，请等候处理" >> $LOG_FILE
		sleep 3s
		acl_flag="ACL4SSR"
		case $acl4ssrsel in
		ZHANG)
			_name="MCC_"
			acl_flag="ZHANG"
			;;
		ZHANG_Area_Fallback)
			_name="MAF_"
			acl_flag="ZHANG"
			;;
		ZHANG_Area_Urltest)
			_name="MAU_"
			acl_flag="ZHANG"
			;;
		ZHANG_Area_NoAuto)
			_name="MAN_"
			acl_flag="ZHANG"
			;;
		ZHANG_Area_Media_NoAuto)
			_name="MAMN_"
			acl_flag="ZHANG"
			;;
		ZHANG_Area_Media)
			_name="MAM_"
			acl_flag="ZHANG"
			;;
		ACL4SSR_Online)
			_name="OL_"
			;;
		ACL4SSR_Online_AdblockPlus)
			_name="AP_"
			;;
		ACL4SSR_Online_NoAuto)
			_name="NA_"
			;;
		ACL4SSR_Online_NoReject)
			_name="NR_"
			;;
		ACL4SSR_Online_Mini)
			_name="Mini_"
			;;
		ACL4SSR_Online_Mini_AdblockPlus)
			_name="MAP_"
			;;
		ACL4SSR_Online_Mini_NoAuto)
			_name="MNA_"
			;;
		ACL4SSR_Online_Mini_Fallback)
			_name="MF_"
			;;
		ACL4SSR_Online_Mini_MultiMode)
			_name="MMM_"
			;;
		ACL4SSR_Online_Full)
			_name="Full_"
			;;
		ACL4SSR_Online_Full_NoAuto)
			_name="FNA_"
			;;
		ACL4SSR_Online_Full_AdblockPlus)
			_name="FAP_"
			;;
		ACL4SSR_Online_Full_Netflix)
			_name="FNX_"
			;;
		ACL4SSR_Online_Full_Google)
			_name="FGG_"
			;;
		ACL4SSR_Online_Full_MultiMode)
			_name="FMM_"
			;;
		ACL4SSR_Online_Mini_MultiCountry)
			_name="MMC_"
			;;
		esac
		if [ "$acl_flag" == "ACL4SSR" ] && [ "$merlinclash_cdn_cbox" == "0" ]; then
			links="${addr}sub?target=$clashtarget&new_name=true&url=$merlinc_link&insert=false&config=https%3a%2f%2fraw.githubusercontent.com%2FACL4SSR%2FACL4SSR%2Fmaster%2FClash%2Fconfig%2f${acl4ssrsel}.ini&include=$include&exclude=$exclude&append_type=$appendtype&emoji=$emoji&udp=$udp&fdn=$fdn&sort=$sort&scv=$scv&tfo=$tfo"
		elif [ "$acl_flag" == "ZHANG" ] && [ "$merlinclash_cdn_cbox" == "0" ]; then
			links="${addr}sub?target=$clashtarget&new_name=true&url=$merlinc_link&insert=false&config=https%3a%2f%2fraw.githubusercontent.com%2Fflyhigherpi%2Fmerlinclash_clash_related%2Fmaster%2FRule_config%2f${acl4ssrsel}.ini&include=$include&exclude=$exclude&append_type=$appendtype&emoji=$emoji&udp=$udp&fdn=$fdn&sort=$sort&scv=$scv&tfo=$tfo"
		elif [ "$acl_flag" == "ACL4SSR" ] && [ "$merlinclash_cdn_cbox" == "1" ]; then
			links="${addr}sub?target=$clashtarget&new_name=true&url=$merlinc_link&insert=false&config=https%3a%2f%2fcdn.jsdelivr.net%2fgh%2Fflyhigherpi%2Fmerlinclash_clash_related%2FRule_config%2FClash%2Fconfig%2f${acl4ssrsel}.ini&include=$include&exclude=$exclude&append_type=$appendtype&emoji=$emoji&udp=$udp&fdn=$fdn&sort=$sort&scv=$scv&tfo=$tfo"
		elif [ "$acl_flag" == "ZHANG" ] && [ "$merlinclash_cdn_cbox" == "1" ]; then
			links="${addr}sub?target=$clashtarget&new_name=true&url=$merlinc_link&insert=false&config=https%3a%2f%2fcdn.jsdelivr.net%2fgh%2Fflyhigherpi%2Fmerlinclash_clash_related%2FRule_config%2FZHANG_CDN%2f${acl4ssrsel}.ini&include=$include&exclude=$exclude&append_type=$appendtype&emoji=$emoji&udp=$udp&fdn=$fdn&sort=$sort&scv=$scv&tfo=$tfo"
		fi	
		if [ -n "$upname_tmp" ]; then
			upname="$_name$upname_tmp.yaml"
		else
			upname="$_name$newname.yaml"
		fi
			#wget下载文件
			#wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$links"
			echo_date "订阅地址是：$links" >> $LOG_FILE
			UA='Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1667.0 Safari/537.36'
			echo_date "使用常规网络下载..." >> $LOG_FILE
			curl --user-agent "$UA" --connect-timeout 30 -s "$links" > /tmp/upload/$upname
			echo_date "配置文件下载完成" >>$LOG_FILE
			if [ "$?" == "0" ];then
				#下载为空...
				if [ -z "$(cat /tmp/upload/$upname)" ]; then
					echo_date "使用curl下载成功，但是内容为空，尝试更换wget进行下载..."	>> $LOG_FILE
					rm /tmp/upload/$upname
					wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$links"
				fi
				echo_date "检查文件完整性" >> $LOG_FILE
				if [ -z "$(cat /tmp/upload/$upname)" ];then 
					echo_date "获取clash配置文件失败！" >> $LOG_FILE
					failed_warning_clash
				else
					#虽然为0但是还是要检测下是否下载到正确的内容
					echo_date "检查下载是否正确" >> $LOG_FILE
					#订阅地址有跳转
					local blank=$(cat /tmp/upload/$upname | grep -E " |Redirecting|301")
					local blank2=$(cat /tmp/upload/$upname | grep -E " |The following link doesn't contain any valid node info")
					local blakflg="0"				
					if [ "$blakflg" == "0" ] && [ -n "$blank" ]; then
						echo_date "订阅链接可能有跳转，尝试更换wget进行下载..." >> $LOG_FILE
						rm /tmp/upload/$upname
						if [ -n $(echo $links | grep -E "^https") ]; then
							wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$links"						
						else
							wget -t3 -T30 -4 -O /tmp/upload/$upname "$links"	
						fi
						blakflg="1"
					fi
					if [ "$blakflg" == "0" ] && [ -n "$blank2" ]; then
						echo_date "curl下载出错，尝试更换wget进行下载..." >> $LOG_FILE
						rm /tmp/upload/$upname
						if [ -n $(echo $links | grep -E "^https") ]; then
							wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$links"						
						else
							wget -t3 -T30 -4 -O /tmp/upload/$upname "$links"	
						fi
						blakflg="1"
					fi
					#下载为空...
					if [ -z "$(cat /tmp/upload/$upname)" ]; then
						echo_date "下载内容为空..."  >> $LOG_FILE
						failed_warning_clash
					fi
					echo_date "已获取clash配置文件" >> $LOG_FILE
					echo_date "yaml文件合法性检查" >> $LOG_FILE	
					check_yamlfile
					if [ $flag == "1" ]; then
					#执行上传文件名.yaml处理工作，包括去注释，去空白行，去除dns以上头部，将标准头部文件复制一份到/tmp/ 跟tmp的标准头部文件合并，生成新的head.yaml，再将head.yaml复制到/koolshare/merlinclash/并命名为upload.yaml
						echo_date "执行yaml文件处理工作" >> $LOG_FILE
						sh /koolshare/scripts/clash_yaml_sub.sh #>/dev/null 2>&1 &
						#20200803写入字典
						write_dictionary
						echo_date "订阅完成" >> $LOG_FILE
					else
						echo_date "yaml文件格式不合法" >> $LOG_FILE
						failed_warning_clash
					fi
				fi
			else
				echo_date "下载超时" >> $LOG_FILE
				failed_warning_clash
			fi
	#fi
}

start_regular_update_384(){
	#$name $type $link $clashtarget $acltype $emoji $udp $appendtype $sort $fnd $include $exclude $scv $tfo
	#$1    $2    $3    $4           $5       $6      $7    $8         $9   ${10} ${11}    ${12}   ${13} ${14}
	emoji=$6
	echo_date "emoji:$emoji" >> $Regularlog

	udp=$7
	echo_date "udp:$udp" >> $Regularlog

	appendtype=$8
	echo_date "节点显示类型:$appendtype" >> $Regularlog

	sort=$9
	echo_date "节点排序:$sort" >> $Regularlog

	fnd=${10}
	echo_date "过滤非法节点:$fnd" >> $Regularlog
	
	scv=${13}
	echo_date "跳过证书验证:$scv" >> $Regularlog

	tfo=${14}
	echo_date "TCP FAST OPEN:$tfo" >> $Regularlog

	include=${11}
	echo_date "包含节点:$include" >> $Regularlog

	exclude=${12}
	echo_date "排除节点:$exclude" >> $Regularlog

	addr=${15}
	echo_date "后端地址:$addr" >> $Regularlog

	updateflag="start_regular_update"

	merlinc_link=$3	
	upname_tmp=$1
	acltype_tmp=$5
	merlinclash_clashtarget=$4
	dbus set merlinclash_clashtarget=$merlinclash_clashtarget
	echo_date "clashtarget: $merlinclash_clashtarget" >> $Regularlog
	echo_date "订阅地址是：$merlinc_link" >> $Regularlog
	echo_date "【配置名是：$upname_tmp】" >> $Regularlog
	echo_date "后端地址是：$addr" >> $Regularlog
	echo_date "订阅规则类型是：$(get_acl4ssrsel_name $acltype_tmp)" >> $Regularlog
	#echo_date "subconverter进程：$(pidof subconverter)" >> $LOG_FILE
	echo_date "即将开始转换，需要一定时间，请等候处理" >> $Regularlog
	sleep 3s
	acl_flag="ACL4SSR"
	case $acltype_tmp in
	ZHANG)
		_name="MCC_"
		acl_flag="ZHANG"
		;;
	ZHANG_Area_Fallback)
		_name="MAF_"
		acl_flag="ZHANG"
		;;
	ZHANG_Area_Urltest)
		_name="MAU_"
		acl_flag="ZHANG"
		;;
	ZHANG_Area_NoAuto)
		_name="MAN_"
		acl_flag="ZHANG"
		;;
	ZHANG_Area_Media_NoAuto)
		_name="MAMN_"
		acl_flag="ZHANG"
		;;
	ZHANG_Area_Media)
		_name="MAM_"
		acl_flag="ZHANG"
		;;
	ACL4SSR_Online)
		_name="OL_"
		;;
	ACL4SSR_Online_AdblockPlus)
		_name="AP_"
		;;
	ACL4SSR_Online_NoAuto)
		_name="NA_"
		;;
	ACL4SSR_Online_NoReject)
		_name="NR_"
		;;
	ACL4SSR_Online_Mini)
		_name="Mini_"
		;;
	ACL4SSR_Online_Mini_AdblockPlus)
		_name="MAP_"
		;;
	ACL4SSR_Online_Mini_NoAuto)
		_name="MNA_"
		;;
	ACL4SSR_Online_Mini_Fallback)
		_name="MF_"
		;;
	ACL4SSR_Online_Mini_MultiMode)
		_name="MMM_"
		;;
	ACL4SSR_Online_Full)
		_name="Full_"
		;;
	ACL4SSR_Online_Full_NoAuto)
		_name="FNA_"
		;;
	ACL4SSR_Online_Full_AdblockPlus)
		_name="FAP_"
		;;
	ACL4SSR_Online_Full_Netflix)
		_name="FNX_"
		;;
	ACL4SSR_Online_Full_Google)
		_name="FGG_"
		;;
	ACL4SSR_Online_Full_MultiMode)
		_name="FMM_"
		;;
	ACL4SSR_Online_Mini_MultiCountry)
		_name="MMC_"
		;;
	esac
	if [ "$acl_flag" == "ACL4SSR" ] && [ "$merlinclash_cdn_cbox" == "0" ]; then
		links="${addr}sub?target=$merlinclash_clashtarget&new_name=true&url=$merlinc_link&insert=false&config=https%3a%2f%2fraw.githubusercontent.com%2fACL4SSR%2fACL4SSR%2fmaster%2fClash%2Fconfig%2f${acltype_tmp}.ini&include=$include&exclude=$exclude&append_type=$appendtype&emoji=$emoji&udp=$udp&fdn=$fdn&sort=$sort&scv=$scv&tfo=$tfo"
	elif [ "$acl_flag" == "ZHANG" ] && [ "$merlinclash_cdn_cbox" == "0" ]; then
		links="${addr}sub?target=$merlinclash_clashtarget&new_name=true&url=$merlinc_link&insert=false&config=https%3a%2f%2fraw.githubusercontent.com%2fflyhigherpi%2fmerlinclash_clash_related%2fmaster%2fRule_config%2f${acltype_tmp}.ini&include=$include&exclude=$exclude&append_type=$appendtype&emoji=$emoji&udp=$udp&fdn=$fdn&sort=$sort&scv=$scv&tfo=$tfo"
	elif [ "$acl_flag" == "ACL4SSR" ] && [ "$merlinclash_cdn_cbox" == "1" ]; then
		links="${addr}sub?target=$merlinclash_clashtarget&new_name=true&url=$merlinc_link&insert=false&config=https%3a%2f%2fcdn.jsdelivr.net%2fgh%2Fflyhigherpi%2fmerlinclash_clash_related%2fRule_config%2FClash%2fconfig%2f${acltype_tmp}.ini&include=$include&exclude=$exclude&append_type=$appendtype&emoji=$emoji&udp=$udp&fdn=$fdn&sort=$sort&scv=$scv&tfo=$tfo"
	elif [ "$acl_flag" == "ZHANG" ] && [ "$merlinclash_cdn_cbox" == "1" ]; then
		links="${addr}sub?target=$merlinclash_clashtarget&new_name=true&url=$merlinc_link&insert=false&config=https%3a%2f%2fcdn.jsdelivr.net%2fgh%2fflyhigherpi%2fmerlinclash_clash_related%2fRule_config%2FZHANG_CDN%2f${acltype_tmp}.ini&include=$include&exclude=$exclude&append_type=$appendtype&emoji=$emoji&udp=$udp&fdn=$fdn&sort=$sort&scv=$scv&tfo=$tfo"
	fi	
	upname="${_name}${upname_tmp}.yaml"
		
	#wget下载文件
	#wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$links"
	UA='Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1667.0 Safari/537.36'
	echo_date "使用常规网络下载..." >> $Regularlog
	curl --user-agent "$UA" --connect-timeout 30 -s "$links" > /tmp/upload/$upname	
	echo_date "配置文件下载完成" >>$Regularlog
	if [ "$?" == "0" ];then
		#下载为空...
		if [ -z "$(cat /tmp/upload/$upname)" ]; then
			echo_date "使用curl下载成功，但是内容为空，尝试更换wget进行下载..."	>> $Regularlog
			rm /tmp/upload/$upname
			wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$links"
		fi
		echo_date "检查文件完整性" >> $Regularlog
		if [ -z "$(cat /tmp/upload/$upname)" ];then 
			echo_date "获取clash配置文件失败！" >> $Regularlog
			failed_warning_clash
		else
			#虽然为0但是还是要检测下是否下载到正确的内容
			echo_date "检查下载是否正确" >> $Regularlog
			#订阅地址有跳转
			local blank=$(cat /tmp/upload/$upname | grep -E " |Redirecting|301")
			local blank2=$(cat /tmp/upload/$upname | grep -E " |The following link doesn't contain any valid node info")
			local blakflg="0"				
			if [ "$blakflg" == "0" ] && [ -n "$blank" ]; then
				echo_date "订阅链接可能有跳转，尝试更换wget进行下载..." >> $Regularlog
				rm /tmp/upload/$upname
				if [ -n $(echo $links | grep -E "^https") ]; then
					wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$links"						
				else
					wget -t3 -T30 -4 -O /tmp/upload/$upname "$links"	
				fi
				blakflg="1"
			fi
			if [ "$blakflg" == "0" ] && [ -n "$blank2" ]; then
				echo_date "curl下载出错，尝试更换wget进行下载..." >> $Regularlog
				rm /tmp/upload/$upname
				if [ -n $(echo $links | grep -E "^https") ]; then
					wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$links"						
				else
					wget -t3 -T30 -4 -O /tmp/upload/$upname "$links"	
				fi
				blakflg="1"
			fi
			#下载为空...
			if [ -z "$(cat /tmp/upload/$upname)" ]; then
				echo_date "下载内容为空..."  >> $Regularlog
				failed_warning_clash
			fi
			echo_date "已获取clash配置文件" >> $Regularlog
			echo_date "yaml文件合法性检查" >> $Regularlog	
			check_yamlfile
			if [ $flag == "1" ]; then
			#执行上传文件名.yaml处理工作，包括去注释，去空白行，去除dns以上头部，将标准头部文件复制一份到/tmp/ 跟tmp的标准头部文件合并，生成新的head.yaml，再将head.yaml复制到/koolshare/merlinclash/并命名为upload.yaml
				echo_date "执行yaml文件处理工作" >> $Regularlog
				sh /koolshare/scripts/clash_yaml_sub.sh #>/dev/null 2>&1 &
				#20200803写入字典
				write_dictionary
				echo_date "订阅完成" >> $Regularlog
			else
				echo_date "yaml文件格式不合法" >> $Regularlog
				failed_warning_clash
			fi
		fi
	else
		echo_date "下载超时" >> $Regularlog
		failed_warning_clash
	fi
}
write_dictionary(){
	if [ -f "$dictionary" ]; then
		name_tmp=$(cat $dictionary | grep -w -n "$upname" | awk -F ":" '{print $1}')
		#定位配置名行数，存在，则覆写；不存在，则新增 -w全字符匹配
		if [ -n "$name_tmp" ]; then
			if [ "$updateflag" == "start_online_update" ]; then
				if [ "$mcflag" == "HND" ]; then
					echo_date "【SubConverter本地转换】配置名存在，覆写" >> $LOG_FILE
					sed -i "$name_tmp d" $dictionary
					if [ "$customrule" == "0" ]; then	
						echo \"name\":\"$upname\",\"link\":\"$merlinc_link\",\"type\":\"$subscription_type\",\"use\":\"0\",\"clashtarget\":\"$clashtarget\",\"acltype\":\"$acl4ssrsel\",\"emoji\":\"$emoji\",\"udp\":\"$udp\",\"appendtype\":\"$appendtype\",\"sort\":\"$sort\",\"fnd\":\"$fnd\",\"include\":\"$include\",\"exclude\":\"$exclude\",\"scv\":\"$scv\",\"tfo\":\"$tfo\",\"customrule\":\"0\" >> $dictionary
					else
						echo \"name\":\"$upname\",\"link\":\"$merlinc_link\",\"type\":\"$subscription_type\",\"use\":\"0\",\"clashtarget\":\"$clashtarget\",\"acltype\":\"$acl4ssrsel\",\"emoji\":\"$emoji\",\"udp\":\"$udp\",\"appendtype\":\"$appendtype\",\"sort\":\"$sort\",\"fnd\":\"$fnd\",\"include\":\"$include\",\"exclude\":\"$exclude\",\"scv\":\"$scv\",\"tfo\":\"$tfo\",\"customrule\":\"1\" >> $dictionary
					fi
				else
					echo_date "【ACL4SSR转换处理】配置名存在，覆写" >> $LOG_FILE
					sed -i "$name_tmp d" $dictionary
					echo \"name\":\"$upname\",\"link\":\"$merlinc_link\",\"type\":\"$subscription_type\",\"use\":\"0\",\"clashtarget\":\"$clashtarget\",\"acltype\":\"$acl4ssrsel\",\"emoji\":\"$emoji\",\"udp\":\"$udp\",\"appendtype\":\"$appendtype\",\"sort\":\"$sort\",\"fnd\":\"$fnd\",\"include\":\"$include\",\"exclude\":\"$exclude\",\"scv\":\"$scv\",\"tfo\":\"$tfo\",\"addr\":\"$addr\" >> $dictionary
				fi
			fi
		else
			#新增
			echo_date "没找到同名配置，开始创建新配置" >> $LOG_FILE
			if [ "$mcflag" == "HND" ]; then
				if [ "$customrule" == "0" ]; then	
					echo \"name\":\"$upname\",\"link\":\"$merlinc_link\",\"type\":\"$subscription_type\",\"use\":\"0\",\"clashtarget\":\"$clashtarget\",\"acltype\":\"$acl4ssrsel\",\"emoji\":\"$emoji\",\"udp\":\"$udp\",\"appendtype\":\"$appendtype\",\"sort\":\"$sort\",\"fnd\":\"$fnd\",\"include\":\"$include\",\"exclude\":\"$exclude\",\"scv\":\"$scv\",\"tfo\":\"$tfo\",\"customrule\":\"0\" >> $dictionary
				else
					echo \"name\":\"$upname\",\"link\":\"$merlinc_link\",\"type\":\"$subscription_type\",\"use\":\"0\",\"clashtarget\":\"$clashtarget\",\"acltype\":\"$acl4ssrsel\",\"emoji\":\"$emoji\",\"udp\":\"$udp\",\"appendtype\":\"$appendtype\",\"sort\":\"$sort\",\"fnd\":\"$fnd\",\"include\":\"$include\",\"exclude\":\"$exclude\",\"scv\":\"$scv\",\"tfo\":\"$tfo\",\"customrule\":\"1\" >> $dictionary
				fi
			else
				echo \"name\":\"$upname\",\"link\":\"$merlinc_link\",\"type\":\"$subscription_type\",\"use\":\"0\",\"clashtarget\":\"$clashtarget\",\"acltype\":\"$acl4ssrsel\",\"emoji\":\"$emoji\",\"udp\":\"$udp\",\"appendtype\":\"$appendtype\",\"sort\":\"$sort\",\"fnd\":\"$fnd\",\"include\":\"$include\",\"exclude\":\"$exclude\",\"scv\":\"$scv\",\"tfo\":\"$tfo\",\"addr\":\"$addr\" >> $dictionary
			fi
		fi
	else
		#为初次订阅，直接写入
		echo_date "初次订阅，直接写入" >> $LOG_FILE
		if [ "$mcflag" == "HND" ]; then
			if [ "$customrule" == "0" ]; then	
					echo \"name\":\"$upname\",\"link\":\"$merlinc_link\",\"type\":\"$subscription_type\",\"use\":\"0\",\"clashtarget\":\"$clashtarget\",\"acltype\":\"$acl4ssrsel\",\"emoji\":\"$emoji\",\"udp\":\"$udp\",\"appendtype\":\"$appendtype\",\"sort\":\"$sort\",\"fnd\":\"$fnd\",\"include\":\"$include\",\"exclude\":\"$exclude\",\"scv\":\"$scv\",\"tfo\":\"$tfo\",\"customrule\":\"0\" >> $dictionary
				else
					echo \"name\":\"$upname\",\"link\":\"$merlinc_link\",\"type\":\"$subscription_type\",\"use\":\"0\",\"clashtarget\":\"$clashtarget\",\"acltype\":\"$acl4ssrsel\",\"emoji\":\"$emoji\",\"udp\":\"$udp\",\"appendtype\":\"$appendtype\",\"sort\":\"$sort\",\"fnd\":\"$fnd\",\"include\":\"$include\",\"exclude\":\"$exclude\",\"scv\":\"$scv\",\"tfo\":\"$tfo\",\"customrule\":\"1\" >> $dictionary
				fi
		else
			echo \"name\":\"$upname\",\"link\":\"$merlinc_link\",\"type\":\"$subscription_type\",\"use\":\"0\",\"clashtarget\":\"$clashtarget\",\"acltype\":\"$acl4ssrsel\",\"emoji\":\"$emoji\",\"udp\":\"$udp\",\"appendtype\":\"$appendtype\",\"sort\":\"$sort\",\"fnd\":\"$fnd\",\"include\":\"$include\",\"exclude\":\"$exclude\",\"scv\":\"$scv\",\"tfo\":\"$tfo\",\"addr\":\"$addr\" >> $dictionary
		fi
	fi
	
}

check_yamlfile(){
	#通过获取的文件是否存在port: Rule: Proxy: Proxy Group: 标题头确认合法性
	para1=$(sed -n '/^port:/p' /tmp/upload/$upname)
	para1_1=$(sed -n '/^mixed-port:/p' /tmp/upload/$upname)
	para2=$(sed -n '/^socks-port:/p' /tmp/upload/$upname)
	proxies_line=$(cat /tmp/upload/$upname | grep -n "^proxies:" | awk -F ":" '{print $1}')
	#20200902+++++++++++++++
	#COMP 左>右，值-1；左等于右，值0；左<右，值1
	port_line=$(cat /tmp/upload/$upname | grep -n "^port:" | awk -F ":" '{print $1}')
	echo_date "port:行数为$port_line" >> $LOG_FILE
	echo_date "proxies:行数为$proxies_line" >> $LOG_FILE
	if [ -z "$port_line" ] ; then
		echo_date "配置文件缺少port:开头行，无法创建yaml文件" >> $LOG_FILE
		failed_warning_clash

	fi
	if [ -z "$proxies_line" ]; then
		echo_date "配置文件缺少proxies:开头行，无法创建yaml文件" >> $LOG_FILE
		failed_warning_clash

	fi
	if [ -z "$para1" ] && [ -z "$para1_1" ]; then
		echo_date "clash配置文件不是合法的yaml文件，请检查订阅连接是否有误" >> $LOG_FILE
		failed_warning_clash
	else
		echo_date "clash配置文件检查通过" >> $LOG_FILE
		flag=1
	fi
}

failed_warning_clash(){
	echo_date "本地获取文件失败！！！" >> $LOG_FILE
	sc_process=$(pidof subconverter)
	if [ -n "$sc_process" ]; then
		echo_date 关闭subconverter进程... >> $LOG_FILE
		killall subconverter >/dev/null 2>&1
	fi
	echo_date "===================================================================" >> $LOG_FILE
	echo BBABBBBC
	exit 1
}

set_lock(){
	exec 233>"$LOCK_FILE"
	flock -n 233 || {
		echo_date "订阅脚本已经在运行，请稍候再试！" >> $LOG_FILE	
		unset_lock
	}
}

unset_lock(){
	flock -u 233
	rm -rf "$LOCK_FILE"
}

case $2 in
16)
	#set_lock
	if [ "$mcflag" == "HND" ]; then
		echo "" > $LOG_FILE
		http_response "$1"
		echo_date "subconverter转换处理" >> $LOG_FILE
		#20200802启动subconverter进程
		/koolshare/bin/subconverter >/dev/null 2>&1 &
		start_online_update_hnd >> $LOG_FILE
		sc_process=$(pidof subconverter)
		if [ -n "$sc_process" ]; then
			echo_date 关闭subconverter进程... >> $LOG_FILE
			killall subconverter >/dev/null 2>&1
		fi
		echo BBABBBBC >> $LOG_FILE
	else
		#set_lock
		echo "" > $LOG_FILE
		http_response "$1"
		echo_date "ACL4SSR转换处理" >> $LOG_FILE
		start_online_update_384 >> $LOG_FILE
		echo BBABBBBC >> $LOG_FILE
		#unset_lock
	fi
	;;
21)
	echo "" > $LOG_FILE
	http_response "$1"
	echo_date "dler三合一转换" >> $LOG_FILE
	#20200802启动subconverter进程
	/koolshare/bin/subconverter >/dev/null 2>&1 &
	start_dc_online_update_hnd >> $LOG_FILE
	sc_process=$(pidof subconverter)
	if [ -n "$sc_process" ]; then
		echo_date 关闭subconverter进程... >> $LOG_FILE
		killall subconverter >/dev/null 2>&1
	fi
	echo BBABBBBC >> $LOG_FILE
	;;
4)
	if [ "$mcflag" == "HND" ]; then
		echo_date "定时转换处理HND" >> $LOG_FILE
		echo_date "定时转换处理HND" >> $Regularlog
		#20200802启动subconverter进程
		/koolshare/bin/subconverter >/dev/null 2>&1 &
		#$name $type $link $clashtarget $acltype $emoji $udp $appendtype $sort $fnd $include $exclude $scv $tfo $customrule
		#$1    $2    $3    $4           $5       $6      $7    $8         $9   ${10} ${11}    ${12}   ${13} ${14} ${15}
		start_regular_update_hnd "$1" "$2" "$3" "$4" "$5" "$6" "$7" "$8" "$9" "${10}" "${11}" "${12}" "${13}" "${14}" "${15}" >> $LOG_FILE
		sc_process=$(pidof subconverter)
		if [ -n "$sc_process" ]; then
			echo_date 关闭subconverter进程... >> $Regularlog
			echo_date "" >> $Regularlog
			killall subconverter >/dev/null 2>&1
		fi
		echo BBABBBBC >> $LOG_FILE
	else
		echo_date "定时转换处理384" >> $LOG_FILE
		echo_date "定时转换处理384" >> $Regularlog
		#$name $type $link $clashtarget $acltype $emoji $udp $appendtype $sort $fnd $include $exclude $scv $tfo
		#$1    $2    $3    $4           $5       $6      $7    $8         $9   ${10} ${11}    ${12}   ${13} ${14}
		start_regular_update_384 "$1" "$2" "$3" "$4" "$5" "$6" "$7" "$8" "$9" "${10}" "${11}" "${12}" "${13}" "${14}" "${15}" >> $LOG_FILE
		echo_date "" >> $Regularlog
		echo BBABBBBC >> $LOG_FILE
	fi
	;;
esac

