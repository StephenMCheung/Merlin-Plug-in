#!/bin/sh

source /koolshare/scripts/base.sh
eval $(dbus export merlinclash)
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'

LOGFILE=/tmp/upload/merlinclash_log.txt
LOG_FILE=/tmp/upload/merlinclash_updateyaml.txt

yamlname=$merlinclash_delyamlsel
#配置文件路径
yamlpath=/koolshare/merlinclash/yaml_use/$yamlname.yaml

filename=/koolshare/merlinclash/yaml_bak/subscription.txt
rm -rf $LOG_FILE
mcflag=$merlinclash_flag

update_yaml_sel(){
	echo_date "待更新的配置文件为：$yamlname，日志文件位置为:$LOG_FILE" >> $LOGFILE
	echo_date "待更新的配置文件为：$yamlname，日志文件位置为:$LOG_FILE" >> $LOG_FILE
	a=$(ls $filename | wc -l)
	if [ $a -gt 0 ]; then
		echo_date "订阅字典文件存在,检查当前配置是否可以手动更新" >> $LOGFILE
		echo_date "订阅字典文件存在,检查当前配置是否可以手动更新" >> $LOG_FILE
		upfile=/tmp/updateyaml.txt
		awk -F, '/"'$yamlname.yaml'"/ {print $0}' $filename > $upfile

		lines=$(cat $upfile | wc -l)
		echo_date "存在字典数据：$lines条" >> $LOGFILE
		echo_date "存在字典数据：$lines条" >> $LOG_FILE
		if [ "$lines" == "1" ]; then
			i=1
			while [ "$i" -le "$lines" ]
			do
				echo_date "开始订阅更新处理" >> $LOGFILE
				echo_date "开始订阅更新处理" >> $LOG_FILE
				sleep 1s
				line=$(sed -n ''$i'p' "$upfile")
				#echo $line
				#echo ""
				name=$(echo $line |grep -o "\"name\".*"|awk -F\" '{print $4}')
				#名字去除.yaml后缀
				name=$(echo $name | awk -F"." '{print $1}')
				link=$(echo $line | grep -o "\"link\".*"|awk -F\" '{print $4}')
				type=$(echo $line | grep -o "\"type\".*"|awk -F\" '{print $4}')
				use=$(echo $line | grep -o "\"use\".*"|awk -F\" '{print $4}')
				ruletype=$(echo $line | grep -o "\"ruletype\".*"|awk -F\" '{print $4}')
				clashtarget=$(echo $line | grep -o "\"clashtarget\".*"|awk -F\" '{print $4}')
				emoji=$(echo $line | grep -o "\"emoji\".*"|awk -F\" '{print $4}')
				udp=$(echo $line | grep -o "\"udp\".*"|awk -F\" '{print $4}')
				appendtype=$(echo $line | grep -o "\"appendtype\".*"|awk -F\" '{print $4}')
				sort=$(echo $line | grep -o "\"sort\".*"|awk -F\" '{print $4}')
				fnd=$(echo $line | grep -o "\"fnd\".*"|awk -F\" '{print $4}')
				include=$(echo $line | grep -o "\"include\".*"|awk -F\" '{print $4}')
				exclude=$(echo $line | grep -o "\"exclude\".*"|awk -F\" '{print $4}')
				scv=$(echo $line | grep -o "\"scv\".*"|awk -F\" '{print $4}')
				tfo=$(echo $line | grep -o "\"tfo\".*"|awk -F\" '{print $4}')
				acltype=$(echo $line | grep -o "\"acltype\".*"|awk -F\" '{print $4}')
				if [ "$mcflag" != "HND" ]; then
					addr=$(echo $line | grep -o "\"addr\".*"|awk -F\" '{print $4}')
					#echo_date "addr=$addr" >> $Regularlog
				else
					customrule=$(echo $line | grep -o "\"customrule\".*"|awk -F\" '{print $4}')
				fi
				echo_date "-----------------------------------------------" >> $LOGFILE
				echo_date "当前更新配置名：$name" >> $LOGFILE
				echo_date "当前更新配置订阅链接：$link" >> $LOGFILE
				echo_date "当前更新配置订阅类型：$type" >> $LOGFILE
				echo_date "-----------------------------------------------" >> $LOGFILE
				echo_date "-----------------------------------------------" >> $LOG_FILE
				echo_date "当前更新配置名：$name" >> $LOG_FILE
				echo_date "当前更新配置订阅链接：$link" >> $LOG_FILE
				echo_date "当前更新配置订阅类型：$type" >> $LOG_FILE
				echo_date "-----------------------------------------------" >> $LOG_FILE
				#echo_date "跳出" >> $LOGFILE
				#echo BBABBBBC >> $LOGFILE
				#exit 1
				#根据type类型调用不同订阅方法
				sleep 2s
				case $type in
				1)
				#	echo "启动方案1"
					/bin/sh /koolshare/scripts/clash_online_yaml.sh "$name" "$type" "$link"
					sleep 3s
					;;
				2)
				#	echo "启动方案2"
					#名字带前缀，先去除前缀
					#name=$(echo $name | awk -F"_" '{print $2}')
					#从左向右截取第一个 _ 后的字符串
					name=$(echo ${name#*_}) 
					/bin/sh /koolshare/scripts/clash_online_yaml2.sh "$name" "$type" "$link" "$ruletype"
					sleep 3s
					;;
				3)
					echo_date "小白一键订阅手动更新" >> $LOGFILE
					echo_date "小白一键订阅手动更新" >> $LOG_FILE
					#名字带前缀，先去除前缀
					#name=$(echo $name | awk -F"_" '{print $2}')
					#从左向右截取第一个 _ 后的字符串
					name=$(echo ${name#*_}) 
					if [ "$mcflag" == "HND" ]; then
						/bin/sh /koolshare/scripts/clash_online_yaml_2.sh "$name" "$type" "$link"
					else
						/bin/sh /koolshare/scripts/clash_online_yaml_2.sh "$name" "$type" "$link" "$addr"
					fi
					sleep 3s
					;;
				4)
					#名字带前缀，先去除前缀
					echo_date "SC/ACL4SSR/DC一键订阅手动更新" >> $LOGFILE
					echo_date "SC/ACL4SSR/DC一键订阅手动更新" >> $LOG_FILE
					#name=$(echo $name | awk -F"_" '{print $2}')
					#从左向右截取第一个 _ 后的字符串
					name=$(echo ${name#*_}) 
					if [ "$mcflag" == "HND" ]; then
						#echo_date "HND" >> $Regularlog
						/bin/sh /koolshare/scripts/clash_online_yaml4.sh "$name" "$type" "$link" "$clashtarget" "$acltype" "$emoji" "$udp" "$appendtype" "$sort" "$fnd" "$include" "$exclude" "$scv" "$tfo" "$customrule"
					else
						/bin/sh /koolshare/scripts/clash_online_yaml4.sh "$name" "$type" "$link" "$clashtarget" "$acltype" "$emoji" "$udp" "$appendtype" "$sort" "$fnd" "$include" "$exclude" "$scv" "$tfo" "$addr"
					fi
					sleep 3s
					;;
				esac
				let i=i+1
			done
			#订阅后重启clash
			sleep 5s
			echo_date "订阅更新完成，为防止启动出错，如更新订阅为当前使用配置，" >> $LOGFILE
			echo_date "请检查配置后手动重新启动clash。" >> $LOGFILE
			echo_date "订阅更新完成，为防止启动出错，如更新订阅为当前使用配置，" >> $LOG_FILE
			echo_date "请检查配置后手动重新启动clash。" >> $LOG_FILE
			#/bin/sh /koolshare/merlinclash/clashconfig.sh restart
		else	
			echo_date "该配置无法进行手动更新" >> $LOGFILE
			echo_date "该配置无法进行手动更新" >> $LOG_FILE
			echo BBABBBBC >> $LOGFILE
			exit 1
		fi
	else
		echo_date "字典丢失" >> $LOGFILE
		echo_date "字典丢失" >> $LOG_FILE
		echo BBABBBBC >> $LOGFILE
		exit 1
	fi
}

case $2 in
0)
	echo "" > $LOGFILE
	http_response "$1"
	echo_date "更新配置文件" >> $LOGFILE
	echo_date "更新配置文件" > $LOG_FILE
	update_yaml_sel >> $LOGFILE
	echo BBABBBBC >> $LOGFILE
	;;
esac


